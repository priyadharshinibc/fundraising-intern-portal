# 🎯 Fundraising Portal UI - Flutter App

A beautifully designed internal fundraising portal built with **Flutter**, integrating **Rive animations** for the login screen, a **sign-up flow**, and a modern **dashboard with pie charts and rewards**.

---

## ✨ Features

- 🧚‍♀️ Rive-based animated **Login Screen**
- 📝 Stylish **Sign-Up Page** with form fields
- 📊 **Dashboard** with:
  - Personalized welcome message
  - Random referral code (e.g., `PRIYA-1234`)
  - Interactive **Pie Chart** showing "Donations Raised vs Target"
  - Dynamic reward section with unlockable icons like 🏆 🎁 🥇 🔒
- 🎨 Clean **pastel theme** UI throughout the app

---

## 🚀 Getting Started

### Prerequisites
- Flutter SDK (>=3.0.0)
- A code editor (VS Code, Android Studio, or FlutLab)

### 🔧 Installation

1. **Clone the repo or download ZIP**

2. **Install dependencies**  
   ```bash
   flutter pub get
