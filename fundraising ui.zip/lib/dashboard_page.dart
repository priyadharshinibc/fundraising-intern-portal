import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  final String internName = "Priya";
  final String referralCode = "PRIYA-1234";
  final double raised = 2500;
  final double target = 5000;

  List<String> getRewards(double raised) {
    List<String> rewards = [];
    if (raised >= 1000) rewards.add("🏆 Trophy");
    if (raised >= 2000) rewards.add("🎁 Gift");
    if (raised >= 3000) rewards.add("🥇 Medal");
    if (raised < 5000) rewards.add("🔒 Locked");
    return rewards;
  }

  @override
  Widget build(BuildContext context) {
    final raisedPercent = (raised / target * 100).toStringAsFixed(1);
    final remainingPercent =
        (100 - double.parse(raisedPercent)).toStringAsFixed(1);
    List<String> unlocked = getRewards(raised);

    return Scaffold(
      backgroundColor:
          const Color(0xFFF3E8FF), // 🌸 Soft pastel purple background
      appBar: AppBar(
        title: const Text("Dashboard"),
        backgroundColor:
            const Color(0xFFCFBAF0), // 💜 Pastel purple-blue app bar
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Welcome, $internName!",
              style: const TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
                color: Color(0xFF5D576B),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              "Referral Code: $referralCode",
              style: const TextStyle(
                fontSize: 16,
                color: Color(0xFF95818D),
              ),
            ),
            const SizedBox(height: 30),
            const Text(
              "Donation Progress",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
                color: Color(0xFF5D576B),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              height: 200,
              child: PieChart(
                PieChartData(
                  sectionsSpace: 2,
                  centerSpaceRadius: 40,
                  sections: [
                    PieChartSectionData(
                      value: raised,
                      title: '$raisedPercent%',
                      color: const Color(0xFFB4F8C8),
                      radius: 50,
                      titleStyle: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                    PieChartSectionData(
                      value: target - raised,
                      title: '$remainingPercent%',
                      color: const Color(0xFFFFD6A5),
                      radius: 50,
                      titleStyle: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 30),
            const Text(
              "Unlocked Rewards",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
                color: Color(0xFF5D576B),
              ),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 15,
              children: getRewards(target).map((reward) {
                bool isUnlocked = unlocked.contains(reward);
                return Chip(
                  label: Text(
                    reward,
                    style: const TextStyle(fontSize: 16),
                  ),
                  backgroundColor:
                      isUnlocked ? const Color(0xFFFDCBFA) : Colors.grey[300],
                );
              }).toList(),
            )
          ],
        ),
      ),
    );
  }
}
